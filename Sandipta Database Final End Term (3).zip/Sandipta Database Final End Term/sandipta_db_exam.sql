-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 07, 2021 at 08:21 AM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sandipta_db_exam`
--

-- --------------------------------------------------------

--
-- Table structure for table `mentors_project`
--

CREATE TABLE `mentors_project` (
  `Mentor_ID` int(11) NOT NULL,
  `Mentor_Name` varchar(50) NOT NULL,
  `Projects` varchar(50) NOT NULL,
  `Organization_Working` varchar(50) NOT NULL,
  `Location` varchar(50) NOT NULL,
  `Specialization` varchar(50) NOT NULL,
  `Website` varchar(50) NOT NULL,
  `Interested` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `mentors_project`
--

INSERT INTO `mentors_project` (`Mentor_ID`, `Mentor_Name`, `Projects`, `Organization_Working`, `Location`, `Specialization`, `Website`, `Interested`) VALUES
(1, 'Yashwant', 'Database', 'Amazon', 'TX', 'Data Engineering', 'http://www.amazon.com', 'Yes'),
(2, 'Nalini', 'Networking', 'Facebook', 'CA', 'Security', 'http://www.facebook.com', 'Yes'),
(3, 'Navpreet', 'Image Analysis', 'Tinder', 'TN', 'Image Processing', 'http://www.tinder.com ', 'No'),
(4, 'Aadya', 'Pattern Recognition', 'Tesla', 'MI', 'Deep Learning', 'http://www.tesla.com ', 'Yes'),
(5, 'Helen Jordan', 'Marketing', 'Boxbars', 'CA', 'Sales Executives', 'http://www.boxbars.com', 'Yes');

-- --------------------------------------------------------

--
-- Stand-in structure for view `q2(a)`
-- (See below for the actual view)
--
CREATE TABLE `q2(a)` (
`Mentor_Name` varchar(50)
,`Projects` varchar(50)
);

-- --------------------------------------------------------

--
-- Structure for view `q2(a)`
--
DROP TABLE IF EXISTS `q2(a)`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `q2(a)`  AS SELECT `mentors_project`.`Mentor_Name` AS `Mentor_Name`, `mentors_project`.`Projects` AS `Projects` FROM `mentors_project` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `mentors_project`
--
ALTER TABLE `mentors_project`
  ADD PRIMARY KEY (`Mentor_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `mentors_project`
--
ALTER TABLE `mentors_project`
  MODIFY `Mentor_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
